package cn.enjoy.service;
public interface UserService {
     void doTransaction();
}